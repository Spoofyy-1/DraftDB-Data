"""One frozen draft-class stack, isolated from all benchmark answers."""
import os
os.environ['OMP_NUM_THREADS']='2'
os.environ['OPENBLAS_NUM_THREADS']='2'
from pathlib import Path
import argparse, hashlib, json, time
import numpy as np
import pandas as pd
import stack_core as C
import preprocessing as P
from member_backend import Backend as MemberBackend
from tab_backend import Backend as TabBackend

CODE=Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(Path(p).read_text())
def write_new(p,v):
    p=Path(p); raw=(json.dumps(v,indent=2,allow_nan=False)+'\n').encode()
    with p.open('xb') as f: f.write(raw); f.flush(); os.fsync(f.fileno())

def load(folder):
    folder=Path(folder); r=read(CODE/'recipe.json'); m=read(folder/'manifest.json')
    assert set(p.name for p in folder.iterdir())=={'training.npz','inference.npz','manifest.json'}
    assert m['year'] in r['years']+r['reference_years'] and m['recipe_sha256']==sha(CODE/'recipe.json')
    for name,h in m['files'].items(): assert sha(folder/name)==h
    with np.load(folder/'training.npz',allow_pickle=False) as f:
        assert set(f.files)=={'X','pid','draft_year','label_value','y','prefix_length','season_end'}
        tr={k:f[k].copy() for k in f.files}
    with np.load(folder/'inference.npz',allow_pickle=False) as f:
        assert set(f.files)=={'X','pid'}; te={k:f[k].copy() for k in f.files}
    pids=tr['pid'].tolist(); qpids=te['pid'].tolist(); cols=r['columns']
    assert m['columns']==cols and len(cols)==127 and len(set(cols))==127
    assert tr['X'].shape==(len(pids),len(cols)) and te['X'].shape==(len(qpids),len(cols))
    assert not set(cols)&{'pid','draft_year','actual_pick','was_drafted','qid'}
    assert len(pids)>=40 and len(qpids)>0 and not set(pids)&set(qpids)
    assert np.array_equal(C.canonical_order(pids),np.arange(len(pids)))
    assert np.array_equal(C.canonical_order(qpids),np.arange(len(qpids)))
    assert np.all((tr['draft_year']>=2008)&(tr['draft_year']<m['year']))
    assert np.all(tr['prefix_length']==1) and np.all(tr['season_end']<=m['year']-1)
    assert np.all(tr['season_end']>=tr['draft_year']+1)
    assert np.isfinite(tr['label_value']).all() and np.isfinite(tr['y']).all()
    assert np.array_equal(C.gaussian_target(tr['label_value'],tr['draft_year']),tr['y'])
    assert not np.isinf(tr['X']).any() and not np.isinf(te['X']).any()
    a=m['label_audit']; assert a['no_unknown_training_WAR_zero_fill'] and a['training_rows']==len(pids)
    assert a['training_max_cohort']==int(tr['draft_year'].max())<m['year']
    assert a['actual_admitted_label_max']==int(tr['season_end'].max())<=m['year']-1
    assert a['target_hash']==C.array_hash(tr['y']) and a['training_PID_hash']==C.digest(pids)
    return r,m,tr,te

def combine(records,recipe,n):
    """Identical integer-rank arithmetic to frozen N stack_predictions.assemble."""
    modes={}; seeds=recipe['seeds']; assert seeds==[0,101,202]
    for mode in seeds+['fixed_three_seed_family_rank_average']:
        total=np.zeros(n,dtype=np.int64)
        for i,member in enumerate(recipe['members']):
            rr=records[i]
            if member['family'].startswith('ridge_'): value=rr[0]['canonical_predictions']
            elif isinstance(mode,int): value=next(x for x in rr if x['seed']==mode)['canonical_predictions']
            else: value=np.sum([C.doubled_ranks(x['canonical_predictions']) for x in rr],axis=0,dtype=np.int64)/(6*n)
            total+=C.doubled_ranks(value)*member['units']
        modes[str(mode)]=(total/(24*n)).tolist()
    return modes

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--input',required=True); ap.add_argument('--output',required=True); ap.add_argument('--preflight',action='store_true'); args=ap.parse_args()
    out=Path(args.output); r,m,tr,te=load(args.input)
    assert r['weight_total']==12 and sum(x['units'] for x in r['members'])==12
    assert len({x['family'].split('_a')[0] for x in r['members']})>=2
    assert all(not Path(x).exists() for x in ['/scoring','/vault','/source_refs','/home/ubuntu/nba/handoff'])
    frozen=read(CODE/'frozen.json')
    for f,h in frozen['files'].items(): assert sha(CODE/f)==h
    runtime=read(CODE/'runtime_support.json')
    for group in ['sources','checkpoint_files']:
        for f,info in runtime[group].items(): assert sha(f)==info['sha256']
    if not args.preflight:
        approval=read(CODE/'approval.json')
        assert approval['approved'] and approval['recipe_sha256']==sha(CODE/'recipe.json')
        assert approval['frozen_code_sha256']==sha(CODE/'frozen.json')
        assert approval['bundle_hashes'][str(m['year'])]==sha(Path(args.input)/'manifest.json')
        if m['year']>=2019: assert approval['reference_gate_passed']
    X=pd.DataFrame(tr['X'],columns=r['columns']); query=pd.DataFrame(te['X'],columns=r['columns'])
    backend=MemberBackend(r['member_protocol']); records=[]; count=0; start=time.time(); cpu_designs={}
    for i,member in enumerate(r['members']):
        cols=r['panels'][member['panel_id']]; a=X[cols]; b=query[cols]; rr=[]
        seeds=[0] if member['family'].startswith('ridge_') else r['seeds']
        for seed in seeds:
            if member['family']=='tabicl':
                expected=P.prepare(a,tr['y'],b,r['tab_profile'],seed,r['tab_protocol'],tr['pid'].tolist(),te['pid'].tolist())
                cpu_designs[f'{i}:{seed}']=expected
            if args.preflight: continue
            if member['family']=='tabicl': raw,audit=TabBackend(r['tab_protocol'],r['tab_profile']).fit_predict(a,tr['y'],b,tr['pid'].tolist(),seed,expected)
            else: raw,audit=backend.fit_predict(member['family'],a,tr['y'],b,seed,tr['pid'].tolist())
            canonical,ties=C.canonicalize(b,raw,te['pid'].tolist()); count+=1
            rr.append({'seed':seed,'raw_predictions':raw.tolist(),'canonical_predictions':canonical.tolist(),'model_audit':audit,'tie_audit':ties})
        records.append(rr)
    common={'year':m['year'],'recipe_sha256':sha(CODE/'recipe.json'),'frozen_code_sha256':sha(CODE/'frozen.json'),'input_manifest_sha256':sha(Path(args.input)/'manifest.json'),'audit':m['label_audit'],'runtime_sha256':sha(CODE/'runtime_support.json'),'test_outcomes_accessed':False,'evaluation_scores_computed':False,'namespace_isolated':True,'seconds':time.time()-start}
    if args.preflight:
        write_new(out/'preflight.json',{**common,'passed':True,'model_fits':0,'preprocessing_designs':cpu_designs}); return
    expected_fits=sum(1 if x['family'].startswith('ridge_') else 3 for x in r['members']); assert count==expected_fits
    stacks=combine(records,r,len(te['pid']))
    for pred in stacks.values(): C.validate_equal_groups(query,pred)
    payload={**common,'model_fits':count,'members':records,'query_pids':te['pid'].tolist(),'stacks':stacks,'training_matrix_hash':C.array_hash(X),'query_matrix_hash':C.array_hash(query),'target_hash':C.array_hash(tr['y'])}
    write_new(out/'predictions.json',payload)
    frame=pd.DataFrame({'pid':te['pid'],'season':m['year'],**{f'seed_{s}':stacks[str(s)] for s in r['seeds']},'score':stacks['fixed_three_seed_family_rank_average']})
    with (out/'predictions.csv').open('x') as f: frame.to_csv(f,index=False,float_format='%.17g')
    write_new(out/'completion.json',{'year':m['year'],'rows':len(frame),'seeds':r['seeds'],'model_fits':count,'predictions_sha256':sha(out/'predictions.json'),'predictions_csv_sha256':sha(out/'predictions.csv'),'scoring_performed':False})
    print(json.dumps({'year':m['year'],'fits':count,'seconds':time.time()-start}))

if __name__=='__main__': main()
