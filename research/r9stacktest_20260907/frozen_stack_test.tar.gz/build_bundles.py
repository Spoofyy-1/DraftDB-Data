"""Prepare one permitted earlier-cohort input bundle per test class; no model fits or answers."""
from pathlib import Path
import hashlib,json,sys
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'code'));import stack_core as C
FEATURES=ROOT.parent/'r9stacktest_features/package';LABELS=ROOT.parent/'r9stacktest_calendar'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def csv(p):return pd.read_csv(p,dtype={'pid':str},float_precision='round_trip')
def save(p,v):
 with p.open('x')as f:f.write(json.dumps(v,indent=2,allow_nan=False)+'\n')
def main():
 r=read(ROOT/'code/recipe.json'); fm=read(FEATURES/'manifest.json')
 assert sha(FEATURES/'manifest.json')=='9ba8624cfe079fb1a91f80e0c10a662a0694f29ddafcf4f0e9bcfd3995c58225'
 assert fm['columns127']==r['columns'] and fm['columns44']==r['panels']['base44']
 assert sha(LABELS/'freeze.json')=='f824ece03e0eeefc3f3c3cacb2215d5c0376785c0130d88f316ad7268db0e90c'
 frames={};metas={}
 for key in ['pre2019']+[str(y)for y in r['years']]:
  for prefix,target in [('features_',frames),('metadata_',metas)]:
   name=prefix+key+'.csv';p=FEATURES/name;assert sha(p)==fm['outputs'][name]['sha256']
   target[key]=csv(p);assert len(target[key])==fm['outputs'][name]['rows'] and list(target[key])==fm['outputs'][name]['columns'] and target[key].pid.is_unique
  assert list(frames[key])==['pid','draft_year']+r['columns'] and list(metas[key])==['pid','draft_year','was_drafted']
  assert frames[key][['pid','draft_year']].equals(metas[key][['pid','draft_year']])
  assert metas[key].was_drafted.isin([0,1]).all()
  if key!='pre2019':assert frames[key].draft_year.eq(int(key)).all()
 assert frames['pre2019'].draft_year.between(2000,2018).all()
 reports={}
 for year in r['years']:
  trpool=pd.concat([frames['pre2019']]+[frames[str(y)]for y in r['years']if y<year],ignore_index=True)
  assert trpool.pid.is_unique and trpool.draft_year.lt(year).all()
  rawq=frames[str(year)].loc[metas[str(year)].was_drafted.eq(1)].copy()
  q=rawq.iloc[C.canonical_order(rawq.pid.tolist())].reset_index(drop=True)
  lm=read(LABELS/str(year)/'manifest.json');lp=LABELS/str(year)/'training_labels.csv';labels=csv(lp)
  assert sha(lp)==lm['export_labels_sha256'] and lm['permitted_season_end']==year-1
  assert list(labels)==['pid','draft_year','ordinal','season_end','war'] and labels.pid.is_unique
  assert labels.ordinal.eq(1).all() and labels.season_end.le(year-1).all() and labels.draft_year.lt(year).all() and np.isfinite(labels.war).all()
  assert not set(labels.pid)&set(q.pid)
  eligible=trpool.loc[trpool.draft_year.ge(2008)&trpool.pid.isin(labels.pid)].copy()
  tr=eligible.iloc[C.canonical_order(eligible.pid.tolist())].reset_index(drop=True)
  facts=labels.set_index('pid').loc[tr.pid].reset_index()
  assert facts.pid.tolist()==tr.pid.tolist() and facts.draft_year.tolist()==tr.draft_year.tolist()
  assert len(tr)==lm['policy_preview']['admitted_training_rows']
  y=C.gaussian_target(facts.war.to_numpy(),tr.draft_year.to_numpy())
  arrays={'X':tr[r['columns']].to_numpy(dtype=float),'pid':np.asarray(tr.pid,dtype=str),'draft_year':tr.draft_year.to_numpy(dtype=int),'label_value':facts.war.to_numpy(dtype=float),'y':y,'prefix_length':np.ones(len(tr),dtype=int),'season_end':facts.season_end.to_numpy(dtype=int)}
  queries={'X':q[r['columns']].to_numpy(dtype=float),'pid':np.asarray(q.pid,dtype=str)}
  assert not np.isinf(arrays['X']).any() and not np.isinf(queries['X']).any() and not set(tr.pid)&set(q.pid)
  audit={'year':year,'training_rows':len(tr),'query_rows':len(q),'training_PID_hash':C.digest(tr.pid.tolist()),'target_hash':C.array_hash(y),'training_max_cohort':int(tr.draft_year.max()),'actual_admitted_label_max':int(facts.season_end.max()),'source_export_label_max':int(labels.season_end.max()),'permitted_label_cutoff':year-1,'no_unknown_training_WAR_zero_fill':True,'calendar_export_sha256':sha(lp),'source_fact_hash':C.digest(facts.to_dict(orient='records')),'query_PID_hash':C.digest(q.pid.tolist()),'training_cohort_counts':{str(int(k)):int(v)for k,v in tr.groupby('draft_year').size().items()},'omitted_H_policy_facts':lm['H_missing_within_frozen_s2008_feature_membership']}
  folder=ROOT/'bundles'/str(year);folder.mkdir()
  np.savez_compressed(folder/'training.npz',**arrays);np.savez_compressed(folder/'inference.npz',**queries)
  # Verify every prepared numeric value, identity order, and label survives serialization.
  for name,values in [('training.npz',arrays),('inference.npz',queries)]:
   with np.load(folder/name,allow_pickle=False)as f:
    for k,v in values.items():
     assert np.array_equal(f[k],v,equal_nan=True) if v.dtype.kind in 'fc' else np.array_equal(f[k],v)
  m={'year':year,'columns':r['columns'],'recipe_sha256':sha(ROOT/'code/recipe.json'),'files':{f:sha(folder/f)for f in ['training.npz','inference.npz']},'label_audit':audit,'feature_package_sha256':sha(FEATURES/'manifest.json'),'label_manifest_sha256':sha(LABELS/str(year)/'manifest.json'),'source_global_model_eligible':False,'scoped_retrospective_diagnostic':True}
  save(folder/'manifest.json',m);reports[str(year)]={'manifest_sha256':sha(folder/'manifest.json'),'training_rows':len(tr),'query_rows':len(q),'actual_label_max':audit['actual_admitted_label_max']}
 save(ROOT/'preparation.json',{'passed':True,'years':reports,'model_fits':0,'test_answers_read':False,'feature_manifest_sha256':sha(FEATURES/'manifest.json'),'calendar_freeze_sha256':sha(LABELS/'freeze.json')})
 print(json.dumps(reports))
if __name__=='__main__':main()
