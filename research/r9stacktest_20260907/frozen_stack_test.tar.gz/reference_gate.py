"""Outcome-free exact transfer gate against the frozen R9N selection; never imports a scorer."""
from pathlib import Path
import argparse,datetime,hashlib,json,math,sys
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
N=ROOT.parent/'r9n'
sys.path.insert(0,str(ROOT/'code'))
import worker as W
import stack_core as C

def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x')as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def rank2(v):
 v=[float(x)for x in v];assert all(math.isfinite(x)for x in v)
 order=sorted(range(len(v)),key=v.__getitem__);out=[None]*len(v);a=0
 while a<len(v):
  b=a+1
  while b<len(v)and v[order[b]]==v[order[a]]:b+=1
  for k in order[a:b]:out[k]=a+b+1
  a=b
 return np.asarray(out,dtype=np.int64)
def independent(records,r,n):
 out={}
 for mode in r['seeds']+['fixed_three_seed_family_rank_average']:
  total=np.zeros(n,dtype=np.int64)
  for rr,member in zip(records,r['members']):
   if member['family'].startswith('ridge_'):v=rr[0]['canonical_predictions']
   elif isinstance(mode,int):v=next(x['canonical_predictions']for x in rr if x['seed']==mode)
   else:v=np.sum([rank2(x['canonical_predictions'])for x in rr],axis=0,dtype=np.int64)/(6*n)
   total+=rank2(v)*member['units']
  out[str(mode)]=(total/(24*n)).tolist()
 return out
def fixtures():
 n=7;pids=[f'fixture_{k}'for k in range(n)]
 frame=pd.DataFrame([[1,np.nan],[1,np.nan],[2,0],[3,4],[3,4],[0,0],[0,1]],columns=['a','b'])
 cases=[
 [[1.,3,2,8,6,5,4],[0,4,3,2,8,1,5],[7,3,4,1,5,2,6]],
 [[1.]*n,[2.]*n,[3.]*n],
 [[0,0,1,1,1,2,3],[3,3,2,2,2,1,0],[0,0,1,1,1,1,1]],
 ]
 checked=0
 for rawrows in cases:
  records=[]
  for fam in ['tabicl','ridge_a30','catboost']:
   rr=[]
   for i,seed in enumerate([0]if fam.startswith('ridge_')else[0,101,202]):
    raw=np.asarray(rawrows[i]);canon,a=C.canonicalize(frame,raw,pids)
    assert canon[0]==canon[1] and canon[3]==canon[4]
    assert canon[0]==math.fsum(sorted(raw[:2]))/2 and canon[3]==math.fsum(sorted(raw[3:5]))/2
    rr.append({'seed':seed,'canonical_predictions':canon.tolist()})
   records.append(rr)
  for units in [[4,4,4],[3,6,3],[9,0,3]]:
   r={'seeds':[0,101,202],'members':[{'family':f,'units':u}for f,u in zip(['tabicl','ridge_a30','catboost'],units)],'weight_total':12}
   actual=W.combine(records,r,n);expected=independent(records,r,n);assert actual==expected
   for v in actual.values():assert v[0]==v[1]and v[3]==v[4]
   checked+=4
 return {'passed':True,'independent_recipe_mode_cases':checked,'ties':'Duplicate input rows, missing entries, flat predictions, tied ranks and multiple seed patterns','no_model_fits':True,'no_query_truth':True}

def verify(paths):
 r=read(ROOT/'code/recipe.json');selection=read(N/'results/selection.json');npf=read(N/'results/independent_verification.json')
 assert npf['passed'] and sha(N/'results/selection.json')==npf['selection_sha256']
 selected=selection['recipe'];assert selected['id']=='profile_stack_0820'
 assert r['members']==selected['members'] and r['weight_total']==selected['weight_total']==12 and r['seeds']==selection['seeds']
 assert r['tab_profile']==selection['tabicl_profile']
 assert r['member_protocol']['ridge']==selection['ridge'] and r['member_protocol']['catboost']==selection['catboost']
 for panel in selection['panels']:assert r['panels'][panel['id']]==panel['columns']
 assert r['columns']==r['panels']['f50_game_team']
 m=read(N/'results/result_manifest.json');finish=read(N/'results/completion.json')
 assert finish['result_manifest_sha256']==sha(N/'results/result_manifest.json')
 assert m['diagnostics_sha256']==sha(N/'results/stack_diagnostics.json')
 # Only anonymous historical prediction vectors are used from this development result.
 archived=[x for x in read(N/'results/stack_diagnostics.json')['prediction_details']if x['architecture']==selected['id']]
 assert len(archived)==12
 nplan=read(N/'plan.json');source_manifest=read(N/'source_refs/manifest.json')
 assert sha(N/'source_refs/manifest.json')==nplan['reference_source_manifest_sha256']
 old={};old_hashes={}
 for tid,info in source_manifest['records'].items():
  path=N/info['file'];assert sha(path)==info['sha256'];v=read(path);old[(v['panel_id'],v['outer_year'])]=v;old_hashes[tid]=info['sha256']
 paths=[Path(p)for p in paths];new={read(path)['year']:(path,read(path))for path in paths}
 assert len(paths)==len(new)==3 and set(new)==set(selection['development_years'])=={2012,2013,2014}
 rows=[];issues=[];prediction_records=0;member_records=0;frozen=read(ROOT/'code/frozen.json')
 for name,h in frozen['files'].items():assert sha(ROOT/'code'/name)==h
 for year,(path,v)in sorted(new.items()):
  assert not v['test_outcomes_accessed'] and not v['evaluation_scores_computed'] and v['namespace_isolated']
  assert v['recipe_sha256']==sha(ROOT/'code/recipe.json') and v['frozen_code_sha256']==sha(ROOT/'code/frozen.json')
  assert v['runtime_sha256']==sha(ROOT/'code/runtime_support.json')
  assert v['model_fits']==7 and len(v['members'])==3
  g=old[('f50_game_team',year)];assert v['query_pids']==g['query_pids']
  assert v['training_matrix_hash']==g['training_matrix_hash'] and v['query_matrix_hash']==g['query_matrix_hash'] and v['target_hash']==g['target_hash']
  task=next(t for t in nplan['tasks']if t['outer_year']==year and t['profile_id']==selection['tabicl_profile']['id'])
  entry=m['tasks'][task['id']];npth=N/'results'/entry['file'];assert sha(npth)==entry['sha256'];nt=read(npth)
  assert nt['query_pids']==v['query_pids'] and nt['training_matrix_hash']==v['training_matrix_hash'] and nt['target_hash']==v['target_hash']
  expected=[]
  for member in r['members']:
   family=member['family'];panel=member['panel_id']
   if family=='tabicl':rr=nt['members']
   else:
    original=old[(panel,year)];rr=[{'seed':s['seed'],**s['members'][family]}for s in original['seed_results']]
    if family.startswith('ridge_'):
     assert all(rr[0]['raw_predictions']==x['raw_predictions']and rr[0]['canonical_predictions']==x['canonical_predictions']for x in rr);rr=rr[:1]
   expected.append(rr)
  for member,newrr,oldrr in zip(r['members'],v['members'],expected):
   assert [a['seed']for a in newrr]==[a['seed']for a in oldrr]
   for a,b in zip(newrr,oldrr):
    family=member['family'];seed=a['seed'];aa=a['model_audit'];ba=b['model_audit']
    for field in ['parameters','input_columns','training_pid_hash','training_matrix_hash','training_target_hash','query_matrix_hash']:assert aa[field]==ba[field],(year,family,seed,field)
    if family=='tabicl':
     for field in ['effective_constructor','generator','preprocessing_design_hash','effective_ensemble_count']:assert aa[field]==ba[field],(year,family,seed,field)
    elif family.startswith('ridge_'):assert aa['preprocessing']==ba['preprocessing'],(year,family,seed,'ridge_preprocessing')
    assert a['tie_audit']['input_vector_hashes']==b['tie_audit']['input_vector_hashes']
    A=np.asarray(a['raw_predictions']);B=np.asarray(b['raw_predictions']);AC=np.asarray(a['canonical_predictions']);BC=np.asarray(b['canonical_predictions'])
    assert A.shape==B.shape==AC.shape==BC.shape==(len(v['query_pids']),)and np.isfinite(A).all()and np.isfinite(B).all()
    exact=bool(np.array_equal(A,B));canonical=bool(np.array_equal(AC,BC));rank_exact=bool(np.array_equal(rank2(AC),rank2(BC)))
    item={'year':year,'family':family,'panel_id':member['panel_id'],'seed':seed,'raw_exact':exact,'canonical_exact':canonical,'canonical_rank_exact':rank_exact,'raw_max_abs_difference':float(np.max(np.abs(A-B))),'rank_changed_rows':int(np.count_nonzero(rank2(AC)!=rank2(BC)))}
    rows.append(item);member_records+=1
    if not exact or not canonical:issues.append({**item,'action':'Gate fails; do not silently relax. Investigate GPU nondeterminism or transfer mismatch before future-year fits.'})
  assert W.combine(v['members'],r,len(v['query_pids']))==independent(v['members'],r,len(v['query_pids']))==v['stacks']
  expected_modes=independent(expected,r,len(v['query_pids']))
  for mode,pred in expected_modes.items():
   prior=next(x for x in archived if x['year']==year and str(x['seed'])==mode)
   assert prior['query_pids']==v['query_pids'] and np.array_equal(pred,prior['prediction'])
   if not np.array_equal(v['stacks'][mode],prior['prediction']):issues.append({'year':year,'mode':mode,'stack_prediction_exact':False,'max_abs_difference':float(np.max(np.abs(np.asarray(v['stacks'][mode])-prior['prediction'])))})
   prediction_records+=1
 return {'passed':not issues,'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixture_proof':fixtures(),'recipe_sha256':sha(ROOT/'code/recipe.json'),'frozen_code_sha256':sha(ROOT/'code/frozen.json'),'source_selection_sha256':sha(N/'results/selection.json'),'source_N_manifest_sha256':sha(N/'results/result_manifest.json'),'source_M_record_hashes':old_hashes,'reference_prediction_hashes':{str(y):sha(path)for y,(path,_)in sorted(new.items())},'member_fold_seed_records':member_records,'stack_prediction_records':prediction_records,'exact_source_prediction_arithmetic':True,'member_comparisons':rows,'issues':issues,'gate_policy':'Exact raw and canonical predictions required; any CatBoost GPU differences are recorded without relaxing the gate.','no_truth_loaded':True,'no_scorer_imported':True,'no_model_fits':True,'no2019plus_access':True}
def main():
 a=argparse.ArgumentParser();a.add_argument('--records',nargs='*');a.add_argument('--output',default=str(ROOT/'results/reference_gate.json'));a.add_argument('--fixtures-only',action='store_true');args=a.parse_args()
 if args.fixtures_only:out=fixtures()
 else:
  assert args.records,'Provide all three reference predictions.json paths';out=verify(args.records)
 write(args.output,out)
 print(json.dumps({k:v for k,v in out.items()if k not in ['member_comparisons','source_M_record_hashes']},indent=2))
 if not out['passed']:sys.exit(2)
if __name__=='__main__':main()
