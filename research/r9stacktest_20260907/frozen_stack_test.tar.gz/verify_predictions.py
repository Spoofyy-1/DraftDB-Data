"""Independent saved-prediction validation before opening any test answers."""
from pathlib import Path
import json,hashlib,sys
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'code'))
import stack_core as C
import preprocessing as P
from worker import combine
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def main():
 f=read(ROOT/'registration/frozen.json')
 for name,h in f['files'].items():assert sha(ROOT/name)==h,name
 recipe=read(ROOT/'code/recipe.json');records=0;models=0
 for y in recipe['years']:
  folder=ROOT/'results'/str(y);r=read(folder/'predictions.json');m=read(ROOT/'bundles'/str(y)/'manifest.json');pre=read(folder/'preflight.json')
  assert r['audit']==m['label_audit'] and r['recipe_sha256']==sha(ROOT/'code/recipe.json')and r['input_manifest_sha256']==sha(ROOT/'bundles'/str(y)/'manifest.json')
  assert pre['passed']and pre['model_fits']==0 and pre['input_manifest_sha256']==r['input_manifest_sha256']
  with np.load(ROOT/'bundles'/str(y)/'training.npz',allow_pickle=False)as tr,np.load(ROOT/'bundles'/str(y)/'inference.npz',allow_pickle=False)as te:
   X=pd.DataFrame(tr['X'],columns=recipe['columns']);q=pd.DataFrame(te['X'],columns=recipe['columns']);pids=te['pid'].tolist()
   assert r['query_pids']==pids and r['training_matrix_hash']==C.array_hash(X)and r['query_matrix_hash']==C.array_hash(q)and r['target_hash']==C.array_hash(tr['y'])
   assert tr['season_end'].max()<=y-1 and tr['draft_year'].max()<y and not set(tr['pid'])&set(te['pid'])
   for i,(member,results)in enumerate(zip(recipe['members'],r['members'])):
    cols=recipe['panels'][member['panel_id']];assert [x['seed']for x in results]==([0]if member['family'].startswith('ridge_')else recipe['seeds'])
    for v in results:
     a=v['model_audit'];raw=np.asarray(v['raw_predictions']);pred,ties=C.canonicalize(q[cols],raw,pids);assert np.array_equal(pred,v['canonical_predictions'])and ties==v['tie_audit']
     assert a['training_matrix_hash']==C.array_hash(X[cols])and a['query_matrix_hash']==C.array_hash(q[cols])and a['training_target_hash']==C.array_hash(tr['y'])and a['training_pid_hash']==C.digest(tr['pid'].tolist())
     if member['family']=='tabicl':
      expected=pre['preprocessing_designs'][f'{i}:{v["seed"]}'];assert a['parameters']==P.parameters(recipe['tab_profile'],v['seed'],recipe['tab_protocol'])and a['generator']==expected['generator']and a['preprocessing_design_hash']==C.digest(expected)
     elif member['family']=='catboost':assert a['parameters']=={**recipe['member_protocol']['catboost']['parameters'],'random_seed':v['seed']}and a['tree_count']==a['checkpoint']==600 and a['actual_device']=='GPU'
     else:assert a['parameters']=={'alpha':30,'solver':'svd'}and a['preprocessing']['training_rows_seen']==len(X)
     models+=1
  assert combine(r['members'],recipe,len(pids))==r['stacks']
  records+=4
 assert models==49 and records==28
 out={'passed':True,'frozen_files_verified':len(f['files']),'model_fit_records_verified':models,'stack_prediction_records_verified':records,'all7preflight_and_actual_TabICL_fingerprints_exact':True,'all_model_parameters_input_target_and_PID_hashes_verified':True,'all_training_actual_season_cutoffs_verified':True,'scoring_performed':False,'test_answers_read':False}
 (ROOT/'results/prediction_verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
