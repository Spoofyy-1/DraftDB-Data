"""Bounded four-worker frozen benchmark prediction queue; no scoring imports."""
from pathlib import Path
import concurrent.futures,json,subprocess,time,hashlib,os
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'results'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(v):
 p=OUT/'state.json';tmp=OUT/'state.tmp';tmp.write_text(json.dumps(v,indent=2)+'\n');os.replace(tmp,p)
def run(y,mode):
 with (OUT/f'{mode}_{y}.log').open('x')as log:
  subprocess.run(['bash',str(ROOT/'run_year_sandbox.sh'),str(y),mode],stdout=log,stderr=subprocess.STDOUT,check=True)
 return y
def main():
 r=json.loads((ROOT/'code/recipe.json').read_text());approval=json.loads((ROOT/'code/approval.json').read_text())
 assert approval['reference_gate_passed'] and approval['approved']
 started=time.time();state={'phase':'Frozen three-model stack test:2019-2025','status':'preflight','years':r['years'],'completed_years':[],'active_workers':0,'model_fits_registered':49,'recipe_sha256':sha(ROOT/'code/recipe.json'),'started':started,'test_scores_read':False,'new_development_experiments':False,'error':None}
 save(state)
 try:
  with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:
   fs={pool.submit(run,y,'preflight'):y for y in r['years']}
   for f in concurrent.futures.as_completed(fs):f.result()
  state['status']='predicting';save(state)
  with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:
   fs={pool.submit(run,y,'fit'):y for y in r['years']}
   for f in concurrent.futures.as_completed(fs):
    year=f.result();state['completed_years'].append(year);state['completed_years'].sort();state['model_fits_completed']=7*len(state['completed_years']);state['active_workers']=min(4,7-len(state['completed_years']));save(state)
  state.update(status='predictions_complete_pending_freeze',active_workers=0,elapsed_seconds=time.time()-started);save(state)
 except Exception as e:
  state.update(status='failed',error=repr(e),active_workers=0);save(state);raise
if __name__=='__main__':main()
